﻿namespace WindowsFormsApp1
{
    partial class FormPacjent
    {
        /// <summary>aaaaaaaaaaaaaaaaabbbbbbbbbb
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.errorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.tabPageDanePacjenta = new System.Windows.Forms.TabPage();
            this.textBoxImie = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.textBoxHaslo = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.buttonZmienDane = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.checkBoxAktywny = new System.Windows.Forms.CheckBox();
            this.textBoxEmail = new System.Windows.Forms.TextBox();
            this.textBoxKodPocztowy = new System.Windows.Forms.TextBox();
            this.textBoxMiasto = new System.Windows.Forms.TextBox();
            this.textBoxTelefon = new System.Windows.Forms.TextBox();
            this.textBoxPesel = new System.Windows.Forms.TextBox();
            this.textBoxAdres = new System.Windows.Forms.TextBox();
            this.textBoxNazwisko = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tabControlPanelLekarza = new System.Windows.Forms.TabControl();
            this.tabPageWizyty = new System.Windows.Forms.TabPage();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.dataGridViewHistoria = new System.Windows.Forms.DataGridView();
            this.dateTimePickerWizyta = new System.Windows.Forms.DateTimePicker();
            this.dataGridViewLekarze = new System.Windows.Forms.DataGridView();
            this.buttonDodajWizyte = new System.Windows.Forms.Button();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.wybranyplik = new System.Windows.Forms.Label();
            this.dataGridViewDocuments = new System.Windows.Forms.DataGridView();
            this.buttonDodajDocument = new System.Windows.Forms.Button();
            this.buttonWybierzPlik = new System.Windows.Forms.Button();
            this.textBoxUwagiDokument = new System.Windows.Forms.TextBox();
            this.comboBoxTypDokumentu = new System.Windows.Forms.ComboBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label23 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            this.tabPageDanePacjenta.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabControlPanelLekarza.SuspendLayout();
            this.tabPageWizyty.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHistoria)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLekarze)).BeginInit();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDocuments)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1855, 15);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(111, 33);
            this.button1.TabIndex = 1;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // errorProvider
            // 
            this.errorProvider.ContainerControl = this;
            // 
            // tabPageDanePacjenta
            // 
            this.tabPageDanePacjenta.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.tabPageDanePacjenta.Controls.Add(this.textBoxImie);
            this.tabPageDanePacjenta.Controls.Add(this.button5);
            this.tabPageDanePacjenta.Controls.Add(this.dateTimePicker1);
            this.tabPageDanePacjenta.Controls.Add(this.textBoxHaslo);
            this.tabPageDanePacjenta.Controls.Add(this.label11);
            this.tabPageDanePacjenta.Controls.Add(this.buttonZmienDane);
            this.tabPageDanePacjenta.Controls.Add(this.label9);
            this.tabPageDanePacjenta.Controls.Add(this.label8);
            this.tabPageDanePacjenta.Controls.Add(this.label7);
            this.tabPageDanePacjenta.Controls.Add(this.label6);
            this.tabPageDanePacjenta.Controls.Add(this.label5);
            this.tabPageDanePacjenta.Controls.Add(this.checkBoxAktywny);
            this.tabPageDanePacjenta.Controls.Add(this.textBoxEmail);
            this.tabPageDanePacjenta.Controls.Add(this.textBoxKodPocztowy);
            this.tabPageDanePacjenta.Controls.Add(this.textBoxMiasto);
            this.tabPageDanePacjenta.Controls.Add(this.textBoxTelefon);
            this.tabPageDanePacjenta.Controls.Add(this.textBoxPesel);
            this.tabPageDanePacjenta.Controls.Add(this.textBoxAdres);
            this.tabPageDanePacjenta.Controls.Add(this.textBoxNazwisko);
            this.tabPageDanePacjenta.Controls.Add(this.label4);
            this.tabPageDanePacjenta.Controls.Add(this.label3);
            this.tabPageDanePacjenta.Controls.Add(this.label2);
            this.tabPageDanePacjenta.Controls.Add(this.label1);
            this.tabPageDanePacjenta.Controls.Add(this.pictureBox1);
            this.errorProvider.SetIconAlignment(this.tabPageDanePacjenta, System.Windows.Forms.ErrorIconAlignment.BottomLeft);
            this.tabPageDanePacjenta.Location = new System.Drawing.Point(4, 25);
            this.tabPageDanePacjenta.Margin = new System.Windows.Forms.Padding(4);
            this.tabPageDanePacjenta.Name = "tabPageDanePacjenta";
            this.tabPageDanePacjenta.Padding = new System.Windows.Forms.Padding(4);
            this.tabPageDanePacjenta.Size = new System.Drawing.Size(1957, 983);
            this.tabPageDanePacjenta.TabIndex = 0;
            this.tabPageDanePacjenta.Text = "Dane Pacjenta";
            // 
            // textBoxImie
            // 
            this.textBoxImie.Location = new System.Drawing.Point(157, 36);
            this.textBoxImie.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxImie.Name = "textBoxImie";
            this.textBoxImie.Size = new System.Drawing.Size(241, 22);
            this.textBoxImie.TabIndex = 0;
            this.textBoxImie.TextChanged += new System.EventHandler(this.textBoxImie_TextChanged);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Silver;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button5.Location = new System.Drawing.Point(303, 418);
            this.button5.Margin = new System.Windows.Forms.Padding(4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(219, 49);
            this.button5.TabIndex = 28;
            this.button5.Text = "Wyloguj";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(127, 369);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(271, 22);
            this.dateTimePicker1.TabIndex = 27;
            // 
            // textBoxHaslo
            // 
            this.textBoxHaslo.Location = new System.Drawing.Point(157, 292);
            this.textBoxHaslo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxHaslo.Name = "textBoxHaslo";
            this.textBoxHaslo.Size = new System.Drawing.Size(241, 22);
            this.textBoxHaslo.TabIndex = 26;
            this.textBoxHaslo.TextChanged += new System.EventHandler(this.textBoxHaslo_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label11.Location = new System.Drawing.Point(11, 294);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(58, 20);
            this.label11.TabIndex = 25;
            this.label11.Text = "Haslo";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // buttonZmienDane
            // 
            this.buttonZmienDane.BackColor = System.Drawing.Color.Silver;
            this.buttonZmienDane.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonZmienDane.Location = new System.Drawing.Point(43, 418);
            this.buttonZmienDane.Margin = new System.Windows.Forms.Padding(4);
            this.buttonZmienDane.Name = "buttonZmienDane";
            this.buttonZmienDane.Size = new System.Drawing.Size(219, 49);
            this.buttonZmienDane.TabIndex = 24;
            this.buttonZmienDane.Text = "Aktualizuj Dane";
            this.buttonZmienDane.UseVisualStyleBackColor = false;
            this.buttonZmienDane.Click += new System.EventHandler(this.buttonZmienDane_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label9.Location = new System.Drawing.Point(624, 47);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(172, 25);
            this.label9.TabIndex = 23;
            this.label9.Text = "Zdjecie Pacjenta";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label8.Location = new System.Drawing.Point(11, 260);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(54, 20);
            this.label8.TabIndex = 22;
            this.label8.Text = "email";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label7.Location = new System.Drawing.Point(9, 197);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 20);
            this.label7.TabIndex = 21;
            this.label7.Text = "Miasto";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.Location = new System.Drawing.Point(9, 166);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 20);
            this.label6.TabIndex = 20;
            this.label6.Text = "Nr Tel.";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(9, 229);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(127, 20);
            this.label5.TabIndex = 19;
            this.label5.Text = "Kod Pocztowy";
            // 
            // checkBoxAktywny
            // 
            this.checkBoxAktywny.AutoSize = true;
            this.checkBoxAktywny.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.checkBoxAktywny.Location = new System.Drawing.Point(445, 30);
            this.checkBoxAktywny.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxAktywny.Name = "checkBoxAktywny";
            this.checkBoxAktywny.Size = new System.Drawing.Size(135, 24);
            this.checkBoxAktywny.TabIndex = 17;
            this.checkBoxAktywny.Text = "Czy Aktywny?";
            this.checkBoxAktywny.UseVisualStyleBackColor = true;
            // 
            // textBoxEmail
            // 
            this.textBoxEmail.Location = new System.Drawing.Point(157, 261);
            this.textBoxEmail.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxEmail.Name = "textBoxEmail";
            this.textBoxEmail.Size = new System.Drawing.Size(241, 22);
            this.textBoxEmail.TabIndex = 16;
            // 
            // textBoxKodPocztowy
            // 
            this.textBoxKodPocztowy.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.textBoxKodPocztowy.Location = new System.Drawing.Point(157, 230);
            this.textBoxKodPocztowy.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxKodPocztowy.Name = "textBoxKodPocztowy";
            this.textBoxKodPocztowy.Size = new System.Drawing.Size(241, 22);
            this.textBoxKodPocztowy.TabIndex = 15;
            // 
            // textBoxMiasto
            // 
            this.textBoxMiasto.Location = new System.Drawing.Point(157, 199);
            this.textBoxMiasto.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxMiasto.Name = "textBoxMiasto";
            this.textBoxMiasto.Size = new System.Drawing.Size(241, 22);
            this.textBoxMiasto.TabIndex = 14;
            // 
            // textBoxTelefon
            // 
            this.textBoxTelefon.Location = new System.Drawing.Point(157, 167);
            this.textBoxTelefon.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxTelefon.Name = "textBoxTelefon";
            this.textBoxTelefon.Size = new System.Drawing.Size(241, 22);
            this.textBoxTelefon.TabIndex = 13;
            // 
            // textBoxPesel
            // 
            this.textBoxPesel.Location = new System.Drawing.Point(157, 133);
            this.textBoxPesel.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxPesel.Name = "textBoxPesel";
            this.textBoxPesel.Size = new System.Drawing.Size(241, 22);
            this.textBoxPesel.TabIndex = 6;
            // 
            // textBoxAdres
            // 
            this.textBoxAdres.Location = new System.Drawing.Point(157, 101);
            this.textBoxAdres.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxAdres.Name = "textBoxAdres";
            this.textBoxAdres.Size = new System.Drawing.Size(241, 22);
            this.textBoxAdres.TabIndex = 2;
            // 
            // textBoxNazwisko
            // 
            this.textBoxNazwisko.Location = new System.Drawing.Point(157, 69);
            this.textBoxNazwisko.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxNazwisko.Name = "textBoxNazwisko";
            this.textBoxNazwisko.Size = new System.Drawing.Size(241, 22);
            this.textBoxNazwisko.TabIndex = 1;
            this.textBoxNazwisko.TextChanged += new System.EventHandler(this.textBoxNazwisko_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(8, 133);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 20);
            this.label4.TabIndex = 12;
            this.label4.Text = "Pesel";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(8, 101);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 20);
            this.label3.TabIndex = 11;
            this.label3.Text = "Adres";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(8, 69);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 20);
            this.label2.TabIndex = 10;
            this.label2.Text = "Nazwisko";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(8, 38);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 20);
            this.label1.TabIndex = 9;
            this.label1.Text = "Imię";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.imagebadge;
            this.pictureBox1.Location = new System.Drawing.Point(544, 90);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(368, 204);
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // tabControlPanelLekarza
            // 
            this.tabControlPanelLekarza.Controls.Add(this.tabPageDanePacjenta);
            this.tabControlPanelLekarza.Controls.Add(this.tabPageWizyty);
            this.tabControlPanelLekarza.Controls.Add(this.tabPage1);
            this.tabControlPanelLekarza.Controls.Add(this.tabPage2);
            this.tabControlPanelLekarza.Cursor = System.Windows.Forms.Cursors.Hand;
            this.errorProvider.SetIconAlignment(this.tabControlPanelLekarza, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.tabControlPanelLekarza.Location = new System.Drawing.Point(16, 15);
            this.tabControlPanelLekarza.Margin = new System.Windows.Forms.Padding(4);
            this.tabControlPanelLekarza.Name = "tabControlPanelLekarza";
            this.tabControlPanelLekarza.SelectedIndex = 0;
            this.tabControlPanelLekarza.Size = new System.Drawing.Size(1965, 1012);
            this.tabControlPanelLekarza.TabIndex = 2;
            // 
            // tabPageWizyty
            // 
            this.tabPageWizyty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.tabPageWizyty.Controls.Add(this.button11);
            this.tabPageWizyty.Controls.Add(this.button10);
            this.tabPageWizyty.Controls.Add(this.label22);
            this.tabPageWizyty.Controls.Add(this.label21);
            this.tabPageWizyty.Controls.Add(this.button2);
            this.tabPageWizyty.Controls.Add(this.button6);
            this.tabPageWizyty.Controls.Add(this.dataGridViewHistoria);
            this.tabPageWizyty.Controls.Add(this.dateTimePickerWizyta);
            this.tabPageWizyty.Controls.Add(this.dataGridViewLekarze);
            this.tabPageWizyty.Controls.Add(this.buttonDodajWizyte);
            this.tabPageWizyty.Location = new System.Drawing.Point(4, 25);
            this.tabPageWizyty.Margin = new System.Windows.Forms.Padding(4);
            this.tabPageWizyty.Name = "tabPageWizyty";
            this.tabPageWizyty.Padding = new System.Windows.Forms.Padding(4);
            this.tabPageWizyty.Size = new System.Drawing.Size(1957, 983);
            this.tabPageWizyty.TabIndex = 6;
            this.tabPageWizyty.Text = "Wizyty";
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.Silver;
            this.button11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button11.Location = new System.Drawing.Point(855, 549);
            this.button11.Margin = new System.Windows.Forms.Padding(4);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(197, 63);
            this.button11.TabIndex = 34;
            this.button11.Text = "Recepty";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.Silver;
            this.button10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button10.Location = new System.Drawing.Point(592, 551);
            this.button10.Margin = new System.Windows.Forms.Padding(4);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(197, 63);
            this.button10.TabIndex = 33;
            this.button10.Text = "Skierowania";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label22.Location = new System.Drawing.Point(587, 48);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(112, 32);
            this.label22.TabIndex = 32;
            this.label22.Text = "Wizyty:";
            this.label22.Click += new System.EventHandler(this.label22_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label21.Location = new System.Drawing.Point(25, 48);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(131, 32);
            this.label21.TabIndex = 31;
            this.label21.Text = "Lekarze:";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Silver;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button2.Location = new System.Drawing.Point(326, 549);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(197, 63);
            this.button2.TabIndex = 30;
            this.button2.Text = "Anuluj Wizyte";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_2);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Silver;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button6.Location = new System.Drawing.Point(1192, 549);
            this.button6.Margin = new System.Windows.Forms.Padding(4);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(197, 62);
            this.button6.TabIndex = 29;
            this.button6.Text = "Wyloguj";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // dataGridViewHistoria
            // 
            this.dataGridViewHistoria.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewHistoria.Location = new System.Drawing.Point(592, 95);
            this.dataGridViewHistoria.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridViewHistoria.Name = "dataGridViewHistoria";
            this.dataGridViewHistoria.RowHeadersWidth = 51;
            this.dataGridViewHistoria.Size = new System.Drawing.Size(501, 383);
            this.dataGridViewHistoria.TabIndex = 7;
            this.dataGridViewHistoria.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewHistoria_CellContentClick);
            // 
            // dateTimePickerWizyta
            // 
            this.dateTimePickerWizyta.Location = new System.Drawing.Point(77, 503);
            this.dateTimePickerWizyta.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePickerWizyta.Name = "dateTimePickerWizyta";
            this.dateTimePickerWizyta.Size = new System.Drawing.Size(265, 22);
            this.dateTimePickerWizyta.TabIndex = 5;
            this.dateTimePickerWizyta.ValueChanged += new System.EventHandler(this.dateTimePickerWizyta_ValueChanged);
            // 
            // dataGridViewLekarze
            // 
            this.dataGridViewLekarze.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewLekarze.Location = new System.Drawing.Point(31, 95);
            this.dataGridViewLekarze.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridViewLekarze.Name = "dataGridViewLekarze";
            this.dataGridViewLekarze.RowHeadersWidth = 51;
            this.dataGridViewLekarze.Size = new System.Drawing.Size(469, 383);
            this.dataGridViewLekarze.TabIndex = 4;
            this.dataGridViewLekarze.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewLekarze_CellContentClick);
            // 
            // buttonDodajWizyte
            // 
            this.buttonDodajWizyte.BackColor = System.Drawing.Color.Silver;
            this.buttonDodajWizyte.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonDodajWizyte.Location = new System.Drawing.Point(77, 551);
            this.buttonDodajWizyte.Margin = new System.Windows.Forms.Padding(4);
            this.buttonDodajWizyte.Name = "buttonDodajWizyte";
            this.buttonDodajWizyte.Size = new System.Drawing.Size(197, 63);
            this.buttonDodajWizyte.TabIndex = 3;
            this.buttonDodajWizyte.Text = "Dodaj Wizyte";
            this.buttonDodajWizyte.UseVisualStyleBackColor = false;
            this.buttonDodajWizyte.Click += new System.EventHandler(this.buttonDodajWizyte_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.tabPage1.Controls.Add(this.label18);
            this.tabPage1.Controls.Add(this.label17);
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.button7);
            this.tabPage1.Controls.Add(this.wybranyplik);
            this.tabPage1.Controls.Add(this.dataGridViewDocuments);
            this.tabPage1.Controls.Add(this.buttonDodajDocument);
            this.tabPage1.Controls.Add(this.buttonWybierzPlik);
            this.tabPage1.Controls.Add(this.textBoxUwagiDokument);
            this.tabPage1.Controls.Add(this.comboBoxTypDokumentu);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage1.Size = new System.Drawing.Size(1957, 983);
            this.tabPage1.TabIndex = 7;
            this.tabPage1.Text = "Dokumentacja Medyczna";
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label18.Location = new System.Drawing.Point(143, 325);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(66, 20);
            this.label18.TabIndex = 32;
            this.label18.Text = "Uwagi:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label17.Location = new System.Drawing.Point(143, 266);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(141, 20);
            this.label17.TabIndex = 31;
            this.label17.Text = "Typ dokumentu:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label16.Location = new System.Drawing.Point(143, 19);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(247, 20);
            this.label16.TabIndex = 30;
            this.label16.Text = "Twoje Dokumenty Medyczne";
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Silver;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button7.Location = new System.Drawing.Point(928, 53);
            this.button7.Margin = new System.Windows.Forms.Padding(4);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(219, 49);
            this.button7.TabIndex = 29;
            this.button7.Text = "Wyloguj";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // wybranyplik
            // 
            this.wybranyplik.AutoSize = true;
            this.wybranyplik.Location = new System.Drawing.Point(601, 721);
            this.wybranyplik.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.wybranyplik.Name = "wybranyplik";
            this.wybranyplik.Size = new System.Drawing.Size(0, 16);
            this.wybranyplik.TabIndex = 5;
            // 
            // dataGridViewDocuments
            // 
            this.dataGridViewDocuments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDocuments.Location = new System.Drawing.Point(147, 53);
            this.dataGridViewDocuments.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridViewDocuments.Name = "dataGridViewDocuments";
            this.dataGridViewDocuments.RowHeadersWidth = 51;
            this.dataGridViewDocuments.Size = new System.Drawing.Size(621, 188);
            this.dataGridViewDocuments.TabIndex = 4;
            this.dataGridViewDocuments.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewDocuments_CellContentClick);
            // 
            // buttonDodajDocument
            // 
            this.buttonDodajDocument.BackColor = System.Drawing.Color.Silver;
            this.buttonDodajDocument.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonDodajDocument.Location = new System.Drawing.Point(348, 596);
            this.buttonDodajDocument.Margin = new System.Windows.Forms.Padding(4);
            this.buttonDodajDocument.Name = "buttonDodajDocument";
            this.buttonDodajDocument.Size = new System.Drawing.Size(182, 54);
            this.buttonDodajDocument.TabIndex = 3;
            this.buttonDodajDocument.Text = "Dodaj Dokument";
            this.buttonDodajDocument.UseVisualStyleBackColor = false;
            this.buttonDodajDocument.Click += new System.EventHandler(this.buttonDodajDocument_Click);
            // 
            // buttonWybierzPlik
            // 
            this.buttonWybierzPlik.BackColor = System.Drawing.Color.Silver;
            this.buttonWybierzPlik.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonWybierzPlik.Location = new System.Drawing.Point(147, 596);
            this.buttonWybierzPlik.Margin = new System.Windows.Forms.Padding(4);
            this.buttonWybierzPlik.Name = "buttonWybierzPlik";
            this.buttonWybierzPlik.Size = new System.Drawing.Size(182, 54);
            this.buttonWybierzPlik.TabIndex = 2;
            this.buttonWybierzPlik.Text = "Wybierz Plik";
            this.buttonWybierzPlik.UseVisualStyleBackColor = false;
            // 
            // textBoxUwagiDokument
            // 
            this.textBoxUwagiDokument.Location = new System.Drawing.Point(147, 349);
            this.textBoxUwagiDokument.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxUwagiDokument.Multiline = true;
            this.textBoxUwagiDokument.Name = "textBoxUwagiDokument";
            this.textBoxUwagiDokument.Size = new System.Drawing.Size(461, 207);
            this.textBoxUwagiDokument.TabIndex = 1;
            // 
            // comboBoxTypDokumentu
            // 
            this.comboBoxTypDokumentu.FormattingEnabled = true;
            this.comboBoxTypDokumentu.Location = new System.Drawing.Point(348, 262);
            this.comboBoxTypDokumentu.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxTypDokumentu.Name = "comboBoxTypDokumentu";
            this.comboBoxTypDokumentu.Size = new System.Drawing.Size(160, 24);
            this.comboBoxTypDokumentu.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.tabPage2.Controls.Add(this.dataGridView1);
            this.tabPage2.Controls.Add(this.label23);
            this.tabPage2.Controls.Add(this.button9);
            this.tabPage2.Controls.Add(this.textBox1);
            this.tabPage2.Controls.Add(this.label20);
            this.tabPage2.Controls.Add(this.comboBox3);
            this.tabPage2.Controls.Add(this.label19);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.button8);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage2.Size = new System.Drawing.Size(1957, 983);
            this.tabPage2.TabIndex = 8;
            this.tabPage2.Text = "Opinie";
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(93, 86);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(561, 152);
            this.dataGridView1.TabIndex = 39;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(878, 106);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(114, 80);
            this.label23.TabIndex = 38;
            this.label23.Text = "1 - Bardzo źle\r\n2 - Źle\r\n3 - Przeciętnie\r\n4 - Dobrze\r\n5 - Bardzo Dobrze\r\n";
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.Silver;
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button9.Location = new System.Drawing.Point(93, 528);
            this.button9.Margin = new System.Windows.Forms.Padding(4);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(219, 49);
            this.button9.TabIndex = 37;
            this.button9.Text = "Dodaj Opinie";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(93, 293);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(561, 159);
            this.textBox1.TabIndex = 36;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label20.Location = new System.Drawing.Point(89, 252);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(105, 20);
            this.label20.TabIndex = 35;
            this.label20.Text = "Komentarz:";
            this.label20.Click += new System.EventHandler(this.label20_Click);
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.comboBox3.Location = new System.Drawing.Point(881, 57);
            this.comboBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(111, 24);
            this.comboBox3.TabIndex = 34;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label19.Location = new System.Drawing.Point(716, 61);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(142, 20);
            this.label19.TabIndex = 33;
            this.label19.Text = "Ocena Lekarza:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label10.Location = new System.Drawing.Point(89, 42);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(72, 20);
            this.label10.TabIndex = 31;
            this.label10.Text = "Lekarz:";
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Silver;
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button8.Location = new System.Drawing.Point(773, 528);
            this.button8.Margin = new System.Windows.Forms.Padding(4);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(219, 49);
            this.button8.TabIndex = 29;
            this.button8.Text = "Wyloguj";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // FormPacjent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1462, 707);
            this.Controls.Add(this.tabControlPanelLekarza);
            this.Controls.Add(this.button1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormPacjent";
            this.Text = "FormPacjent";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            this.tabPageDanePacjenta.ResumeLayout(false);
            this.tabPageDanePacjenta.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabControlPanelLekarza.ResumeLayout(false);
            this.tabPageWizyty.ResumeLayout(false);
            this.tabPageWizyty.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHistoria)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLekarze)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDocuments)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ErrorProvider errorProvider;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TabControl tabControlPanelLekarza;
        private System.Windows.Forms.TabPage tabPageDanePacjenta;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox checkBoxAktywny;
        private System.Windows.Forms.TextBox textBoxEmail;
        private System.Windows.Forms.TextBox textBoxKodPocztowy;
        private System.Windows.Forms.TextBox textBoxMiasto;
        private System.Windows.Forms.TextBox textBoxTelefon;
        private System.Windows.Forms.TextBox textBoxPesel;
        private System.Windows.Forms.TextBox textBoxAdres;
        private System.Windows.Forms.TextBox textBoxNazwisko;
        private System.Windows.Forms.TextBox textBoxImie;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TabPage tabPageWizyty;
        private System.Windows.Forms.DateTimePicker dateTimePickerWizyta;
        private System.Windows.Forms.DataGridView dataGridViewLekarze;
        private System.Windows.Forms.Button buttonDodajWizyte;
        private System.Windows.Forms.DataGridView dataGridViewHistoria;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.ComboBox comboBoxTypDokumentu;
        private System.Windows.Forms.TextBox textBoxUwagiDokument;
        private System.Windows.Forms.DataGridView dataGridViewDocuments;
        private System.Windows.Forms.Button buttonDodajDocument;
        private System.Windows.Forms.Button buttonWybierzPlik;
        private System.Windows.Forms.Label wybranyplik;
        private System.Windows.Forms.Button buttonZmienDane;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox textBoxHaslo;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button ZakonczWizyte;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}