﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp1
{
    public partial class FormZarzadzajLekarzami : Form
    {
        public FormZarzadzajLekarzami()
        {
            InitializeComponent();
        }
    }
}
