﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp1
{
    public partial class FormZarzadzajPacjentami : Form
    {
        public FormZarzadzajPacjentami()
        {
            InitializeComponent();
        }
    }
}
