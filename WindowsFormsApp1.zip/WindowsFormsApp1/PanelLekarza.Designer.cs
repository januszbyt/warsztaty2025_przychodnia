﻿namespace WindowsFormsApp1
{
    partial class PanelLekarza
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label label4;
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabPageUstawienia = new System.Windows.Forms.TabPage();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.buttonZmienHaslo = new System.Windows.Forms.Button();
            this.txtHaslo = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.labelLekarzId = new System.Windows.Forms.Label();
            this.labelLekarzImieNazwisko = new System.Windows.Forms.Label();
            this.labelSpecjalizacja = new System.Windows.Forms.Label();
            this.tabPagePowiadomienia = new System.Windows.Forms.TabPage();
            this.button8 = new System.Windows.Forms.Button();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.tabPageEdycjaWizyty = new System.Windows.Forms.TabPage();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.buttonZatwierdz = new System.Windows.Forms.Button();
            this.buttonZatwierdzRecepte = new System.Windows.Forms.Button();
            this.dataGridViewPacjenci = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.Recepta = new System.Windows.Forms.Label();
            this.OPIS = new System.Windows.Forms.Label();
            this.txtRecepta = new System.Windows.Forms.TextBox();
            this.txtZalecenia = new System.Windows.Forms.TextBox();
            this.txtSkierowanie = new System.Windows.Forms.TextBox();
            this.btnZapisz = new System.Windows.Forms.Button();
            this.btnSkierowanie = new System.Windows.Forms.Button();
            this.btnRecepta = new System.Windows.Forms.Button();
            this.tabPagePacjenci = new System.Windows.Forms.TabPage();
            this.buttonPokazInformacje = new System.Windows.Forms.Button();
            this.dataGridViewWizytyhehe = new System.Windows.Forms.DataGridView();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dateTimePickerPacjenci = new System.Windows.Forms.DateTimePicker();
            this.textBoxImieNazwisko = new System.Windows.Forms.TextBox();
            this.buttonSzukaj = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tabPageWizyty = new System.Windows.Forms.TabPage();
            this.buttonAnulujWizyte = new System.Windows.Forms.Button();
            this.buttonPrzyszleWizyty = new System.Windows.Forms.Button();
            this.buttonPrzeszleWizyty = new System.Windows.Forms.Button();
            this.monthCalendar2 = new System.Windows.Forms.MonthCalendar();
            this.dataGridViewWizyty = new System.Windows.Forms.DataGridView();
            this.btnSzukaj = new System.Windows.Forms.Button();
            this.buttonPokazPacjentow = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPageUstawienia.SuspendLayout();
            this.tabPagePowiadomienia.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.tabPageEdycjaWizyty.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPacjenci)).BeginInit();
            this.tabPagePacjenci.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewWizytyhehe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabPageWizyty.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewWizyty)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(444, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(86, 25);
            this.label5.TabIndex = 4;
            this.label5.Text = "Pacjenci";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(64, 93);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(199, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "Wpisz Imię Inazwisko";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(60, 133);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(280, 45);
            this.textBox1.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button1.Location = new System.Drawing.Point(60, 261);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(175, 49);
            this.button1.TabIndex = 1;
            this.button1.Text = "Wyszukaj";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Silver;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button5.Location = new System.Drawing.Point(1179, 583);
            this.button5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(163, 82);
            this.button5.TabIndex = 0;
            this.button5.Text = "Wyloguj";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click_1);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(449, 58);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(597, 334);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // tabPageUstawienia
            // 
            this.tabPageUstawienia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.tabPageUstawienia.Controls.Add(this.textBox2);
            this.tabPageUstawienia.Controls.Add(this.textBox12);
            this.tabPageUstawienia.Controls.Add(this.textBox11);
            this.tabPageUstawienia.Controls.Add(this.textBox10);
            this.tabPageUstawienia.Controls.Add(this.textBox9);
            this.tabPageUstawienia.Controls.Add(this.textBox8);
            this.tabPageUstawienia.Controls.Add(this.textBox7);
            this.tabPageUstawienia.Controls.Add(this.textBox6);
            this.tabPageUstawienia.Controls.Add(this.textBox5);
            this.tabPageUstawienia.Controls.Add(this.textBox4);
            this.tabPageUstawienia.Controls.Add(this.textBox3);
            this.tabPageUstawienia.Controls.Add(this.button3);
            this.tabPageUstawienia.Controls.Add(this.buttonZmienHaslo);
            this.tabPageUstawienia.Controls.Add(this.txtHaslo);
            this.tabPageUstawienia.Controls.Add(this.txtEmail);
            this.tabPageUstawienia.Controls.Add(this.dateTimePicker);
            this.tabPageUstawienia.Controls.Add(this.monthCalendar1);
            this.tabPageUstawienia.Controls.Add(this.label15);
            this.tabPageUstawienia.Controls.Add(this.label14);
            this.tabPageUstawienia.Controls.Add(this.label13);
            this.tabPageUstawienia.Controls.Add(this.label12);
            this.tabPageUstawienia.Controls.Add(this.label11);
            this.tabPageUstawienia.Controls.Add(this.label3);
            this.tabPageUstawienia.Controls.Add(this.label10);
            this.tabPageUstawienia.Controls.Add(label4);
            this.tabPageUstawienia.Controls.Add(this.labelLekarzId);
            this.tabPageUstawienia.Controls.Add(this.labelLekarzImieNazwisko);
            this.tabPageUstawienia.Controls.Add(this.labelSpecjalizacja);
            this.tabPageUstawienia.Location = new System.Drawing.Point(4, 25);
            this.tabPageUstawienia.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPageUstawienia.Name = "tabPageUstawienia";
            this.tabPageUstawienia.Size = new System.Drawing.Size(1099, 991);
            this.tabPageUstawienia.TabIndex = 5;
            this.tabPageUstawienia.Text = "Dane Lekarza";
            this.tabPageUstawienia.Click += new System.EventHandler(this.tabPageUstawienia_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(197, 163);
            this.textBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(251, 31);
            this.textBox2.TabIndex = 39;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(198, 519);
            this.textBox12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox12.Multiline = true;
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(251, 31);
            this.textBox12.TabIndex = 33;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(198, 469);
            this.textBox11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox11.Multiline = true;
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(251, 31);
            this.textBox11.TabIndex = 32;
            this.textBox11.TextChanged += new System.EventHandler(this.textBox11_TextChanged);
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(198, 419);
            this.textBox10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox10.Multiline = true;
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(251, 31);
            this.textBox10.TabIndex = 31;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(198, 367);
            this.textBox9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox9.Multiline = true;
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(251, 31);
            this.textBox9.TabIndex = 30;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(198, 317);
            this.textBox8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox8.Multiline = true;
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(251, 31);
            this.textBox8.TabIndex = 29;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(197, 265);
            this.textBox7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox7.Multiline = true;
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(251, 31);
            this.textBox7.TabIndex = 28;
            this.textBox7.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(197, 212);
            this.textBox6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox6.Multiline = true;
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(251, 31);
            this.textBox6.TabIndex = 27;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(198, 110);
            this.textBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(251, 31);
            this.textBox5.TabIndex = 26;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(197, 56);
            this.textBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(251, 31);
            this.textBox4.TabIndex = 24;
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(198, 6);
            this.textBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(251, 34);
            this.textBox3.TabIndex = 21;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Silver;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button3.Location = new System.Drawing.Point(220, 578);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(229, 82);
            this.button3.TabIndex = 22;
            this.button3.Text = "Zmień Dane";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // buttonZmienHaslo
            // 
            this.buttonZmienHaslo.Location = new System.Drawing.Point(1267, 681);
            this.buttonZmienHaslo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttonZmienHaslo.Name = "buttonZmienHaslo";
            this.buttonZmienHaslo.Size = new System.Drawing.Size(100, 28);
            this.buttonZmienHaslo.TabIndex = 14;
            this.buttonZmienHaslo.Text = "Zatwierdz";
            this.buttonZmienHaslo.UseVisualStyleBackColor = true;
            // 
            // txtHaslo
            // 
            this.txtHaslo.Location = new System.Drawing.Point(1241, 638);
            this.txtHaslo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtHaslo.Name = "txtHaslo";
            this.txtHaslo.Size = new System.Drawing.Size(132, 22);
            this.txtHaslo.TabIndex = 13;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(1241, 613);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(132, 22);
            this.txtEmail.TabIndex = 12;
            // 
            // dateTimePicker
            // 
            this.dateTimePicker.Location = new System.Drawing.Point(1171, 183);
            this.dateTimePicker.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.Size = new System.Drawing.Size(265, 22);
            this.dateTimePicker.TabIndex = 10;
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(692, 36);
            this.monthCalendar1.Margin = new System.Windows.Forms.Padding(12, 11, 12, 11);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 11;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label15.Location = new System.Drawing.Point(40, 172);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(95, 20);
            this.label15.TabIndex = 40;
            this.label15.Text = "Nazwisko:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label14.Location = new System.Drawing.Point(32, 528);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(67, 22);
            this.label14.TabIndex = 38;
            this.label14.Text = "Hasło:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label13.Location = new System.Drawing.Point(34, 478);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(72, 22);
            this.label13.TabIndex = 37;
            this.label13.Text = "E-mail:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label12.Location = new System.Drawing.Point(34, 428);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(141, 22);
            this.label12.TabIndex = 36;
            this.label12.Text = "Kod Pocztowy:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label11.Location = new System.Drawing.Point(37, 378);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(71, 20);
            this.label11.TabIndex = 35;
            this.label11.Text = "Miasto:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(37, 223);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 20);
            this.label3.TabIndex = 34;
            this.label3.Text = "Adres:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label10.Location = new System.Drawing.Point(37, 326);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(128, 22);
            this.label10.TabIndex = 23;
            this.label10.Text = "Nr. Telefonu:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            label4.Location = new System.Drawing.Point(37, 274);
            label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(66, 22);
            label4.TabIndex = 20;
            label4.Text = "Pesel:";
            // 
            // labelLekarzId
            // 
            this.labelLekarzId.AutoSize = true;
            this.labelLekarzId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelLekarzId.Location = new System.Drawing.Point(40, 16);
            this.labelLekarzId.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelLekarzId.Name = "labelLekarzId";
            this.labelLekarzId.Size = new System.Drawing.Size(34, 20);
            this.labelLekarzId.TabIndex = 1;
            this.labelLekarzId.Text = "ID:";
            this.labelLekarzId.Click += new System.EventHandler(this.labelLekarzId_Click);
            // 
            // labelLekarzImieNazwisko
            // 
            this.labelLekarzImieNazwisko.AutoSize = true;
            this.labelLekarzImieNazwisko.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelLekarzImieNazwisko.Location = new System.Drawing.Point(41, 119);
            this.labelLekarzImieNazwisko.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelLekarzImieNazwisko.Name = "labelLekarzImieNazwisko";
            this.labelLekarzImieNazwisko.Size = new System.Drawing.Size(50, 20);
            this.labelLekarzImieNazwisko.TabIndex = 2;
            this.labelLekarzImieNazwisko.Text = "Imie:";
            this.labelLekarzImieNazwisko.Click += new System.EventHandler(this.labelLekarzImieNazwisko_Click);
            // 
            // labelSpecjalizacja
            // 
            this.labelSpecjalizacja.AutoSize = true;
            this.labelSpecjalizacja.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelSpecjalizacja.Location = new System.Drawing.Point(37, 64);
            this.labelSpecjalizacja.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelSpecjalizacja.Name = "labelSpecjalizacja";
            this.labelSpecjalizacja.Size = new System.Drawing.Size(127, 20);
            this.labelSpecjalizacja.TabIndex = 3;
            this.labelSpecjalizacja.Text = "Specjalizacja:";
            this.labelSpecjalizacja.Click += new System.EventHandler(this.labelSpecjalizacja_Click);
            // 
            // tabPagePowiadomienia
            // 
            this.tabPagePowiadomienia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.tabPagePowiadomienia.Controls.Add(this.button8);
            this.tabPagePowiadomienia.Controls.Add(this.dataGridView3);
            this.tabPagePowiadomienia.Location = new System.Drawing.Point(4, 25);
            this.tabPagePowiadomienia.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPagePowiadomienia.Name = "tabPagePowiadomienia";
            this.tabPagePowiadomienia.Size = new System.Drawing.Size(1099, 991);
            this.tabPagePowiadomienia.TabIndex = 4;
            this.tabPagePowiadomienia.Text = "Powiadomienia";
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button8.Location = new System.Drawing.Point(40, 624);
            this.button8.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(272, 76);
            this.button8.TabIndex = 20;
            this.button8.Text = "Wyślij Powiadomienie";
            this.button8.UseVisualStyleBackColor = false;
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(40, 82);
            this.dataGridView3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowHeadersWidth = 51;
            this.dataGridView3.RowTemplate.Height = 24;
            this.dataGridView3.Size = new System.Drawing.Size(1101, 494);
            this.dataGridView3.TabIndex = 0;
            // 
            // tabPageEdycjaWizyty
            // 
            this.tabPageEdycjaWizyty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.tabPageEdycjaWizyty.Controls.Add(this.label17);
            this.tabPageEdycjaWizyty.Controls.Add(this.label18);
            this.tabPageEdycjaWizyty.Controls.Add(this.textBox16);
            this.tabPageEdycjaWizyty.Controls.Add(this.textBox15);
            this.tabPageEdycjaWizyty.Controls.Add(this.label16);
            this.tabPageEdycjaWizyty.Controls.Add(this.label9);
            this.tabPageEdycjaWizyty.Controls.Add(this.label8);
            this.tabPageEdycjaWizyty.Controls.Add(this.buttonZatwierdz);
            this.tabPageEdycjaWizyty.Controls.Add(this.buttonZatwierdzRecepte);
            this.tabPageEdycjaWizyty.Controls.Add(this.dataGridViewPacjenci);
            this.tabPageEdycjaWizyty.Controls.Add(this.label2);
            this.tabPageEdycjaWizyty.Controls.Add(this.Recepta);
            this.tabPageEdycjaWizyty.Controls.Add(this.OPIS);
            this.tabPageEdycjaWizyty.Controls.Add(this.txtRecepta);
            this.tabPageEdycjaWizyty.Controls.Add(this.txtZalecenia);
            this.tabPageEdycjaWizyty.Controls.Add(this.txtSkierowanie);
            this.tabPageEdycjaWizyty.Controls.Add(this.btnZapisz);
            this.tabPageEdycjaWizyty.Controls.Add(this.btnSkierowanie);
            this.tabPageEdycjaWizyty.Controls.Add(this.btnRecepta);
            this.tabPageEdycjaWizyty.Location = new System.Drawing.Point(4, 25);
            this.tabPageEdycjaWizyty.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPageEdycjaWizyty.Name = "tabPageEdycjaWizyty";
            this.tabPageEdycjaWizyty.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPageEdycjaWizyty.Size = new System.Drawing.Size(1099, 991);
            this.tabPageEdycjaWizyty.TabIndex = 2;
            this.tabPageEdycjaWizyty.Text = "Edycja Wizyty";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label17.Location = new System.Drawing.Point(755, 274);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(129, 29);
            this.label17.TabIndex = 33;
            this.label17.Text = "Diagnoza:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label18.Location = new System.Drawing.Point(387, 274);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(75, 29);
            this.label18.TabIndex = 32;
            this.label18.Text = "Opis:";
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(760, 308);
            this.textBox16.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox16.Multiline = true;
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(332, 214);
            this.textBox16.TabIndex = 31;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(392, 308);
            this.textBox15.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox15.Multiline = true;
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(332, 214);
            this.textBox15.TabIndex = 30;
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(0, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(89, 18);
            this.label16.TabIndex = 3;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label9.Location = new System.Drawing.Point(300, 14);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(153, 25);
            this.label9.TabIndex = 29;
            this.label9.Text = "Dane Pacjenta";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label8.Location = new System.Drawing.Point(24, 274);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(134, 29);
            this.label8.TabIndex = 28;
            this.label8.Text = "Zalecenia:";
            // 
            // buttonZatwierdz
            // 
            this.buttonZatwierdz.BackColor = System.Drawing.Color.Silver;
            this.buttonZatwierdz.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonZatwierdz.Location = new System.Drawing.Point(29, 565);
            this.buttonZatwierdz.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttonZatwierdz.Name = "buttonZatwierdz";
            this.buttonZatwierdz.Size = new System.Drawing.Size(221, 66);
            this.buttonZatwierdz.TabIndex = 26;
            this.buttonZatwierdz.Text = "Zatwierdz";
            this.buttonZatwierdz.UseVisualStyleBackColor = false;
            this.buttonZatwierdz.Click += new System.EventHandler(this.buttonZatwierdz_Click);
            // 
            // buttonZatwierdzRecepte
            // 
            this.buttonZatwierdzRecepte.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.buttonZatwierdzRecepte.Location = new System.Drawing.Point(1277, 375);
            this.buttonZatwierdzRecepte.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttonZatwierdzRecepte.Name = "buttonZatwierdzRecepte";
            this.buttonZatwierdzRecepte.Size = new System.Drawing.Size(151, 39);
            this.buttonZatwierdzRecepte.TabIndex = 25;
            this.buttonZatwierdzRecepte.Text = "Zatwierdz";
            this.buttonZatwierdzRecepte.UseVisualStyleBackColor = false;
            // 
            // dataGridViewPacjenci
            // 
            this.dataGridViewPacjenci.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPacjenci.Location = new System.Drawing.Point(331, 69);
            this.dataGridViewPacjenci.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridViewPacjenci.Name = "dataGridViewPacjenci";
            this.dataGridViewPacjenci.RowHeadersWidth = 51;
            this.dataGridViewPacjenci.Size = new System.Drawing.Size(740, 178);
            this.dataGridViewPacjenci.TabIndex = 24;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1549, 565);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 16);
            this.label2.TabIndex = 23;
            this.label2.Text = "Diagnoza";
            // 
            // Recepta
            // 
            this.Recepta.AutoSize = true;
            this.Recepta.Location = new System.Drawing.Point(1636, 48);
            this.Recepta.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Recepta.Name = "Recepta";
            this.Recepta.Size = new System.Drawing.Size(59, 16);
            this.Recepta.TabIndex = 22;
            this.Recepta.Text = "Recepta";
            // 
            // OPIS
            // 
            this.OPIS.AutoSize = true;
            this.OPIS.Location = new System.Drawing.Point(1549, 549);
            this.OPIS.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.OPIS.Name = "OPIS";
            this.OPIS.Size = new System.Drawing.Size(38, 16);
            this.OPIS.TabIndex = 21;
            this.OPIS.Text = "OPIS";
            // 
            // txtRecepta
            // 
            this.txtRecepta.BackColor = System.Drawing.SystemColors.HotTrack;
            this.txtRecepta.Location = new System.Drawing.Point(1091, 69);
            this.txtRecepta.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtRecepta.Multiline = true;
            this.txtRecepta.Name = "txtRecepta";
            this.txtRecepta.Size = new System.Drawing.Size(399, 368);
            this.txtRecepta.TabIndex = 15;
            // 
            // txtZalecenia
            // 
            this.txtZalecenia.Location = new System.Drawing.Point(1107, 599);
            this.txtZalecenia.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtZalecenia.Multiline = true;
            this.txtZalecenia.Name = "txtZalecenia";
            this.txtZalecenia.Size = new System.Drawing.Size(368, 190);
            this.txtZalecenia.TabIndex = 20;
            // 
            // txtSkierowanie
            // 
            this.txtSkierowanie.Location = new System.Drawing.Point(29, 308);
            this.txtSkierowanie.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSkierowanie.Multiline = true;
            this.txtSkierowanie.Name = "txtSkierowanie";
            this.txtSkierowanie.Size = new System.Drawing.Size(332, 214);
            this.txtSkierowanie.TabIndex = 14;
            // 
            // btnZapisz
            // 
            this.btnZapisz.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnZapisz.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnZapisz.Location = new System.Drawing.Point(916, 668);
            this.btnZapisz.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnZapisz.Name = "btnZapisz";
            this.btnZapisz.Size = new System.Drawing.Size(155, 52);
            this.btnZapisz.TabIndex = 17;
            this.btnZapisz.Text = "Zapisz";
            this.btnZapisz.UseVisualStyleBackColor = false;
            // 
            // btnSkierowanie
            // 
            this.btnSkierowanie.BackColor = System.Drawing.Color.Silver;
            this.btnSkierowanie.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnSkierowanie.Location = new System.Drawing.Point(29, 69);
            this.btnSkierowanie.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSkierowanie.Name = "btnSkierowanie";
            this.btnSkierowanie.Size = new System.Drawing.Size(221, 74);
            this.btnSkierowanie.TabIndex = 18;
            this.btnSkierowanie.Text = "Skierowanie";
            this.btnSkierowanie.UseVisualStyleBackColor = false;
            this.btnSkierowanie.Click += new System.EventHandler(this.btnSkierowanie_Click_1);
            // 
            // btnRecepta
            // 
            this.btnRecepta.BackColor = System.Drawing.Color.Silver;
            this.btnRecepta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnRecepta.Location = new System.Drawing.Point(29, 172);
            this.btnRecepta.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnRecepta.Name = "btnRecepta";
            this.btnRecepta.Size = new System.Drawing.Size(221, 75);
            this.btnRecepta.TabIndex = 16;
            this.btnRecepta.Text = "Recepta";
            this.btnRecepta.UseVisualStyleBackColor = false;
            this.btnRecepta.Click += new System.EventHandler(this.btnRecepta_Click_1);
            // 
            // tabPagePacjenci
            // 
            this.tabPagePacjenci.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.tabPagePacjenci.Controls.Add(this.buttonPokazInformacje);
            this.tabPagePacjenci.Controls.Add(this.dataGridViewWizytyhehe);
            this.tabPagePacjenci.Controls.Add(this.label7);
            this.tabPagePacjenci.Controls.Add(this.label6);
            this.tabPagePacjenci.Controls.Add(this.dateTimePickerPacjenci);
            this.tabPagePacjenci.Controls.Add(this.textBoxImieNazwisko);
            this.tabPagePacjenci.Controls.Add(this.buttonSzukaj);
            this.tabPagePacjenci.Controls.Add(this.dataGridView2);
            this.tabPagePacjenci.Location = new System.Drawing.Point(4, 25);
            this.tabPagePacjenci.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPagePacjenci.Name = "tabPagePacjenci";
            this.tabPagePacjenci.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPagePacjenci.Size = new System.Drawing.Size(1099, 991);
            this.tabPagePacjenci.TabIndex = 1;
            this.tabPagePacjenci.Text = "Pacjenci";
            // 
            // buttonPokazInformacje
            // 
            this.buttonPokazInformacje.BackColor = System.Drawing.Color.Silver;
            this.buttonPokazInformacje.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonPokazInformacje.Location = new System.Drawing.Point(827, 473);
            this.buttonPokazInformacje.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttonPokazInformacje.Name = "buttonPokazInformacje";
            this.buttonPokazInformacje.Size = new System.Drawing.Size(197, 64);
            this.buttonPokazInformacje.TabIndex = 7;
            this.buttonPokazInformacje.Text = "Pokaz informacje";
            this.buttonPokazInformacje.UseVisualStyleBackColor = false;
            this.buttonPokazInformacje.Click += new System.EventHandler(this.buttonPokazInformacje_Click_1);
            // 
            // dataGridViewWizytyhehe
            // 
            this.dataGridViewWizytyhehe.AllowUserToOrderColumns = true;
            this.dataGridViewWizytyhehe.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewWizytyhehe.Location = new System.Drawing.Point(365, 294);
            this.dataGridViewWizytyhehe.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridViewWizytyhehe.Name = "dataGridViewWizytyhehe";
            this.dataGridViewWizytyhehe.RowHeadersWidth = 51;
            this.dataGridViewWizytyhehe.RowTemplate.Height = 24;
            this.dataGridViewWizytyhehe.Size = new System.Drawing.Size(660, 160);
            this.dataGridViewWizytyhehe.TabIndex = 6;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label7.Location = new System.Drawing.Point(39, 14);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(206, 25);
            this.label7.TabIndex = 5;
            this.label7.Text = "Wpisz Imię i Nazwisko";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.Location = new System.Drawing.Point(372, 14);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(134, 25);
            this.label6.TabIndex = 4;
            this.label6.Text = "Lista Pacjenta";
            // 
            // dateTimePickerPacjenci
            // 
            this.dateTimePickerPacjenci.Location = new System.Drawing.Point(827, 18);
            this.dateTimePickerPacjenci.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dateTimePickerPacjenci.Name = "dateTimePickerPacjenci";
            this.dateTimePickerPacjenci.Size = new System.Drawing.Size(200, 22);
            this.dateTimePickerPacjenci.TabIndex = 3;
            // 
            // textBoxImieNazwisko
            // 
            this.textBoxImieNazwisko.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBoxImieNazwisko.Location = new System.Drawing.Point(35, 68);
            this.textBoxImieNazwisko.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxImieNazwisko.Multiline = true;
            this.textBoxImieNazwisko.Name = "textBoxImieNazwisko";
            this.textBoxImieNazwisko.Size = new System.Drawing.Size(285, 52);
            this.textBoxImieNazwisko.TabIndex = 2;
            this.textBoxImieNazwisko.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // buttonSzukaj
            // 
            this.buttonSzukaj.BackColor = System.Drawing.Color.Silver;
            this.buttonSzukaj.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonSzukaj.Location = new System.Drawing.Point(85, 142);
            this.buttonSzukaj.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttonSzukaj.Name = "buttonSzukaj";
            this.buttonSzukaj.Size = new System.Drawing.Size(197, 64);
            this.buttonSzukaj.TabIndex = 1;
            this.buttonSzukaj.Text = "Wyszukaj";
            this.buttonSzukaj.UseVisualStyleBackColor = false;
            this.buttonSzukaj.Click += new System.EventHandler(this.buttonSzukaj_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToOrderColumns = true;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(368, 68);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(660, 160);
            this.dataGridView2.TabIndex = 0;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // tabPageWizyty
            // 
            this.tabPageWizyty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.tabPageWizyty.Controls.Add(this.buttonAnulujWizyte);
            this.tabPageWizyty.Controls.Add(this.buttonPrzyszleWizyty);
            this.tabPageWizyty.Controls.Add(this.buttonPrzeszleWizyty);
            this.tabPageWizyty.Controls.Add(this.monthCalendar2);
            this.tabPageWizyty.Controls.Add(this.dataGridViewWizyty);
            this.tabPageWizyty.Controls.Add(this.btnSzukaj);
            this.tabPageWizyty.Controls.Add(this.buttonPokazPacjentow);
            this.tabPageWizyty.Location = new System.Drawing.Point(4, 25);
            this.tabPageWizyty.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPageWizyty.Name = "tabPageWizyty";
            this.tabPageWizyty.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPageWizyty.Size = new System.Drawing.Size(1099, 991);
            this.tabPageWizyty.TabIndex = 0;
            this.tabPageWizyty.Text = "Wizyty";
            // 
            // buttonAnulujWizyte
            // 
            this.buttonAnulujWizyte.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.buttonAnulujWizyte.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonAnulujWizyte.Location = new System.Drawing.Point(17, 551);
            this.buttonAnulujWizyte.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonAnulujWizyte.Name = "buttonAnulujWizyte";
            this.buttonAnulujWizyte.Size = new System.Drawing.Size(205, 50);
            this.buttonAnulujWizyte.TabIndex = 26;
            this.buttonAnulujWizyte.Text = "Anuluj Wizytę ";
            this.buttonAnulujWizyte.UseVisualStyleBackColor = false;
            // 
            // buttonPrzyszleWizyty
            // 
            this.buttonPrzyszleWizyty.BackColor = System.Drawing.Color.Silver;
            this.buttonPrzyszleWizyty.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonPrzyszleWizyty.Location = new System.Drawing.Point(17, 470);
            this.buttonPrzyszleWizyty.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonPrzyszleWizyty.Name = "buttonPrzyszleWizyty";
            this.buttonPrzyszleWizyty.Size = new System.Drawing.Size(205, 53);
            this.buttonPrzyszleWizyty.TabIndex = 25;
            this.buttonPrzyszleWizyty.Text = "Zaplanowane Wizyty";
            this.buttonPrzyszleWizyty.UseVisualStyleBackColor = false;
            this.buttonPrzyszleWizyty.Click += new System.EventHandler(this.buttonPrzyszleWizyty_Click_1);
            // 
            // buttonPrzeszleWizyty
            // 
            this.buttonPrzeszleWizyty.BackColor = System.Drawing.Color.Silver;
            this.buttonPrzeszleWizyty.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonPrzeszleWizyty.Location = new System.Drawing.Point(17, 383);
            this.buttonPrzeszleWizyty.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonPrzeszleWizyty.Name = "buttonPrzeszleWizyty";
            this.buttonPrzeszleWizyty.Size = new System.Drawing.Size(205, 53);
            this.buttonPrzeszleWizyty.TabIndex = 24;
            this.buttonPrzeszleWizyty.Text = "Odbyte Wizyty";
            this.buttonPrzeszleWizyty.UseVisualStyleBackColor = false;
            this.buttonPrzeszleWizyty.Click += new System.EventHandler(this.buttonPrzeszleWizyty_Click_1);
            // 
            // monthCalendar2
            // 
            this.monthCalendar2.AllowDrop = true;
            this.monthCalendar2.BackColor = System.Drawing.SystemColors.Highlight;
            this.monthCalendar2.Location = new System.Drawing.Point(17, 44);
            this.monthCalendar2.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.TabIndex = 23;
            this.monthCalendar2.TitleBackColor = System.Drawing.SystemColors.ActiveBorder;
            this.monthCalendar2.TrailingForeColor = System.Drawing.Color.Silver;
            // 
            // dataGridViewWizyty
            // 
            this.dataGridViewWizyty.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewWizyty.Location = new System.Drawing.Point(397, 68);
            this.dataGridViewWizyty.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridViewWizyty.Name = "dataGridViewWizyty";
            this.dataGridViewWizyty.RowHeadersWidth = 51;
            this.dataGridViewWizyty.Size = new System.Drawing.Size(672, 476);
            this.dataGridViewWizyty.TabIndex = 22;
            this.dataGridViewWizyty.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewWizyty_CellContentClick);
            // 
            // btnSzukaj
            // 
            this.btnSzukaj.BackColor = System.Drawing.Color.Silver;
            this.btnSzukaj.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnSzukaj.Location = new System.Drawing.Point(17, 298);
            this.btnSzukaj.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSzukaj.Name = "btnSzukaj";
            this.btnSzukaj.Size = new System.Drawing.Size(205, 54);
            this.btnSzukaj.TabIndex = 19;
            this.btnSzukaj.Text = "Szukaj Wizyty";
            this.btnSzukaj.UseVisualStyleBackColor = false;
            this.btnSzukaj.Click += new System.EventHandler(this.btnSzukaj_Click);
            // 
            // buttonPokazPacjentow
            // 
            this.buttonPokazPacjentow.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.buttonPokazPacjentow.Location = new System.Drawing.Point(549, 398);
            this.buttonPokazPacjentow.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttonPokazPacjentow.Name = "buttonPokazPacjentow";
            this.buttonPokazPacjentow.Size = new System.Drawing.Size(151, 38);
            this.buttonPokazPacjentow.TabIndex = 22;
            this.buttonPokazPacjentow.Text = "Pokaz Pacjentow";
            this.buttonPokazPacjentow.UseVisualStyleBackColor = false;
            this.buttonPokazPacjentow.Click += new System.EventHandler(this.buttonPokazPacjentow_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPageWizyty);
            this.tabControl1.Controls.Add(this.tabPagePacjenci);
            this.tabControl1.Controls.Add(this.tabPageEdycjaWizyty);
            this.tabControl1.Controls.Add(this.tabPagePowiadomienia);
            this.tabControl1.Controls.Add(this.tabPageUstawienia);
            this.tabControl1.Location = new System.Drawing.Point(32, 39);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1107, 1020);
            this.tabControl1.TabIndex = 23;
            // 
            // PanelLekarza
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1396, 832);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.tabControl1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "PanelLekarza";
            this.Text = "PanelLekarza";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPageUstawienia.ResumeLayout(false);
            this.tabPageUstawienia.PerformLayout();
            this.tabPagePowiadomienia.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.tabPageEdycjaWizyty.ResumeLayout(false);
            this.tabPageEdycjaWizyty.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPacjenci)).EndInit();
            this.tabPagePacjenci.ResumeLayout(false);
            this.tabPagePacjenci.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewWizytyhehe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabPageWizyty.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewWizyty)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TabPage tabPageUstawienia;
        private System.Windows.Forms.Button buttonZmienHaslo;
        private System.Windows.Forms.TextBox txtHaslo;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.Label labelLekarzImieNazwisko;
        private System.Windows.Forms.Label labelSpecjalizacja;
        private System.Windows.Forms.TabPage tabPagePowiadomienia;
        private System.Windows.Forms.TabPage tabPageEdycjaWizyty;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button buttonZatwierdz;
        private System.Windows.Forms.Button buttonZatwierdzRecepte;
        private System.Windows.Forms.DataGridView dataGridViewPacjenci;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Recepta;
        private System.Windows.Forms.Label OPIS;
        private System.Windows.Forms.TextBox txtRecepta;
        private System.Windows.Forms.TextBox txtZalecenia;
        private System.Windows.Forms.TextBox txtSkierowanie;
        private System.Windows.Forms.Button btnZapisz;
        private System.Windows.Forms.Button btnSkierowanie;
        private System.Windows.Forms.Button btnRecepta;
        private System.Windows.Forms.TabPage tabPagePacjenci;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker dateTimePickerPacjenci;
        private System.Windows.Forms.TextBox textBoxImieNazwisko;
        private System.Windows.Forms.Button buttonSzukaj;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TabPage tabPageWizyty;
        private System.Windows.Forms.DataGridView dataGridViewWizyty;
        private System.Windows.Forms.Button btnSzukaj;
        private System.Windows.Forms.Button buttonPokazPacjentow;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.MonthCalendar monthCalendar2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label labelLekarzId;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonPrzyszleWizyty;
        private System.Windows.Forms.Button buttonPrzeszleWizyty;
        private System.Windows.Forms.Button buttonAnulujWizyte;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DataGridView dataGridViewWizytyhehe;
        private System.Windows.Forms.Button buttonPokazInformacje;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox15;
    }
}